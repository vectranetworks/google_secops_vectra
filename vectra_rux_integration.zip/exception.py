class VectraException(Exception):
    pass


class UnauthorizeException(VectraException):
    """
    Unauthorized user
    """

    pass


class RefreshTokenException(VectraException):
    """
    Exception if refresh token is expired or invalid
    """

    pass


class RateLimitException(VectraException):
    """
    Exception for rate limit
    """

    pass


class InternalSeverError(VectraException):
    """
    Internal Server Error
    """

    pass


class BadRequestException(VectraException):
    """
    Exception for bad request
    """

    pass
