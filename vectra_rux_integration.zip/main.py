from constant import (
    ENV_CLIENT_ID_SECRECT_NAME,
    ENV_CLIENT_SECRET_SECRET_NAME,
    ENV_VECTRA_BASE_URL,
    ENV_VAR_AUDIT,
    ENV_VAR_DETECTION,
    ENV_VAR_HEALTH,
    ENV_VAR_LOCKDOWN,
    ENV_VAR_SCORING,
    ENV_GCP_BUCKET_NAME,
)
from utils import SecretManagerClient, get_environment_variable, run_methods_with_intervals
from vectra_client import VectraClient

from common import utils


def main(request):
    try:
        secret_manager_client = SecretManagerClient()
        client_id = secret_manager_client.get_secrets(secret_name=get_environment_variable(ENV_CLIENT_ID_SECRECT_NAME, is_required=True, is_secret=True), secret_format_is_json_type=False)
        client_secrets = secret_manager_client.get_secrets(secret_name=get_environment_variable(ENV_CLIENT_SECRET_SECRET_NAME, is_required=True, is_secret=True), secret_format_is_json_type=False)
        base_url = get_environment_variable(ENV_VECTRA_BASE_URL, is_required=True)
        bucket_name = get_environment_variable(ENV_GCP_BUCKET_NAME, is_required=True)

        vectra_client = VectraClient(
            client_id=client_id,
            client_secret=client_secrets,
            base_url=base_url,
            bucket_name=bucket_name,
            secret_manager_client=secret_manager_client,
        )

        methods_map = {
            ENV_VAR_DETECTION: vectra_client.get_and_ingest_detection_events,
            ENV_VAR_SCORING: vectra_client.get_and_ingest_entity_scoring_events,
            ENV_VAR_LOCKDOWN: vectra_client.get_and_ingest_lockdown_events,
            ENV_VAR_AUDIT: vectra_client.get_and_ingest_audit_events,
            ENV_VAR_HEALTH: vectra_client.get_and_ingest_health_events,
        }

        # Get enabled methods from environment variables
        enabled_methods = []
        for method_name, method_func in methods_map.items():
            if get_environment_variable(method_name) == "true":
                enabled_methods.append(method_func)

        # Check if there are no methods to run
        if not enabled_methods:
            utils.cloud_logging("No methods enabled. Please set environment variables.", severity="ERROR")
            return "No methods enabled. Please set proper environment variables.", 400

        utils.cloud_logging(
            f"Enabled methods: {', '.join([method.__name__ for method in enabled_methods])}",
        )
        # Run enabled methods with intervals
        try:
            run_methods_with_intervals(enabled_methods)
            utils.cloud_logging("Methods executed successfully.")
            return "data ingestion completed"
        except Exception as e:
            utils.cloud_logging(f"Unknown exception occurred while executing methods parallelly. Error message: {str(e)}", severity="ERROR")
            return f"Error executing methods: {str(e)}"

    except Exception as e:
        utils.cloud_logging(
            f"Unknown exception occurred while retrieving the environment credentials. Error message: {e}",
            severity="ERROR",
        )
        return f"Error initializing: {str(e)}", 500