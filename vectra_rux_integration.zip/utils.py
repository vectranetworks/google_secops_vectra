import json
import time
import concurrent.futures

from typing import Callable
from google.auth import default
from google.cloud import secretmanager
from google.api_core.exceptions import NotFound

from common import status
from common import utils

from constant import ERRORS, ENV_GCP_PROJECT_NUMBER, DEFAULT_VALUES, METHOD_INTERVAL, VECTRA_ACCESS_TOKEN_ENDPOINT

from exception import (
    BadRequestException,
    InternalSeverError,
    RefreshTokenException,
    UnauthorizeException,
    VectraException,
)


class SecretManagerClient:
    def __init__(self):
        # Get default credentials for the client
        credentials, _ = default()
        # Create a Secret Manager client
        self.client = secretmanager.SecretManagerServiceClient(credentials=credentials)
        self.project_id = get_environment_variable(ENV_GCP_PROJECT_NUMBER, is_required=True)
        utils.cloud_logging("Secret Manager Client Initialized.")

    def get_secrets(self, secret_name, secret_format_is_json_type=True):
        try:
            if "project" not in secret_name:
                secret_name = f"projects/{self.project_id}/secrets/{secret_name}"
            if "versions" not in secret_name:
                secret_name = secret_name + "/versions/latest"
            secret_payload = self.client.access_secret_version(name=secret_name)
            secret_payload = secret_payload.payload.data.decode("UTF-8")
            if secret_format_is_json_type:
                secret_payload = json.loads(secret_payload)
            return secret_payload
        except NotFound as e:
            utils.cloud_logging("Secret not found while retrieving the secret.")
            raise VectraException(e)
        except Exception as e:
            utils.cloud_logging(f"Unknown exception occurred while retrieving the secret. Error message: {e}")
            raise VectraException(e)

    def set_or_update_secrets(self, secret_name: str, secret_payload: dict):
        secret_data = json.dumps(secret_payload)
        payload = secret_data.encode("UTF-8")
        try:
            self.client.add_secret_version(
                parent=f"projects/{self.project_id}/secrets/{secret_name}",
                payload={"data": payload},
            )
        except NotFound:
            utils.cloud_logging("Secret not found while updating the secret. Hence creating a new secret.")
            secret = self.client.create_secret(
                parent=f"projects/{self.project_id}",
                secret_id=secret_name,
                secret={"replication": {"automatic": {}}},
            )
            self.client.add_secret_version(parent=secret.name, payload={"data": payload})
        except Exception as e:
            utils.cloud_logging(f"Unknown exception occurred while updating the secret. Error message: {e}")
            raise VectraException(e)


class HandleExceptions:
    """
    A class to handle exceptions based on different actions.
    """

    def __init__(self, url, error, response, error_msg="An error occurred"):
        """
        Initializes the HandleExceptions class.

        Args:
            url (str): API name.
            error (Exception): The error that occurred.
            error_msg (str, optional): A default error message. Defaults to "An error occurred".
        """
        self.url = url
        self.error = error
        self.response = response
        self.error_msg = error_msg

    def do_process(self):
        """
        Processes the error by calling the appropriate handler.
        """
        if self.response.status_code >= status.STATUS_INTERNAL_SERVER_ERROR:
            utils.cloud_logging(f"It seems like the Vectra server is experiencing some issues, Status: {self.response.status_code}")
            raise InternalSeverError(f"It seems like the Vectra server is experiencing some issues, Status: {self.response.status_code}")
        try:
            _exception, _error_msg = self.get_handler()
        except Exception as e:
            utils.cloud_logging(f"Unknown exception occurred while getting the handler. Error message: {e}")
            _exception, _error_msg = self.common_exception()

        raise _exception(_error_msg)

    def get_handler(self):
        """
        Retrieves the appropriate handler function based on the api_name.

        Returns:
            function: The handler function corresponding to the api_name.
        """
        if VECTRA_ACCESS_TOKEN_ENDPOINT in self.url:
            return self.auth_handle()
        return self.common_exception()

    def common_exception(self):
        """
        Handles common exceptions that don't have a specific handler.

        If the response status code is 400, it calls the appropriate handler for bad request errors.
        Otherwise, it calls the general error handler.
        """
        if self.response.status_code == status.STATUS_BAD_REQUEST:
            return self._handle_bad_request_error()
        elif self.response.status_code == status.STATUS_UNAUTHORIZED:
            return UnauthorizeException, "UnauthorizeException"

        return self._handle_general_error()

    def _handle_general_error(self):
        """
        Handles general errors by formatting the error message and returning the appropriate
        exception.

        Returns:
            tuple: A tuple containing the exception class and the formatted error message.
        """
        error_msg = "{error_msg}: {error} - {text}".format(error_msg=self.error_msg, error=self.error, text=self.response.content)

        return VectraException, error_msg

    def _handle_bad_request_error(self):
        error_response = self.response.json()

        if isinstance(error_response, list) and len(error_response) > 0:
            # If the response is a list, return the first error message
            return BadRequestException, error_response[0]
        elif isinstance(error_response, dict):
            if "_meta" in error_response:
                # Remove the _meta key from the error response
                del error_response["_meta"]

            # Extract the error message from the response
            error_msg = error_response.get(list(error_response.keys())[0])
            return BadRequestException, error_msg

        # If no error message is found, return the general error message
        return self._handle_general_error()

    def auth_handle(self):
        """
        Handles connectivity exceptions that don't have a specific handler.

        If the response status code is 400, it calls the appropriate handler for bad request errors.
        Otherwise, it calls the common error handler.
        """
        res = self.response.json()
        error_msg = res.get("error")
        if self.response.status_code == status.STATUS_BAD_REQUEST:
            return RefreshTokenException, error_msg
        elif self.response.status_code == status.STATUS_UNAUTHORIZED:
            if ERRORS["REFRESH_TOKEN_EXPIRE_MESSAGE"] in error_msg:
                return RefreshTokenException, error_msg
            return UnauthorizeException, error_msg

        return self.common_exception()


def get_environment_variable(name: str, is_required=False, is_secret=False) -> str:
    """
    Retrieves the value of the given environment variable.

    If is_secret is set to True, the value of the environment variable is not modified.
    Otherwise, the value is converted to lower case.

    Args:
        name (str): The name of the environment variable.
        is_required (bool, optional): If the environment variable is required and not set, it raises a RuntimeError. Defaults to False.
        is_secret (bool, optional): If the environment variable is a secret and should not be modified. Defaults to False.

    Returns:
        str: The value of the given environment variable or the default value if it is not set.
    """
    default = DEFAULT_VALUES.get(name, "")
    env_value = utils.get_env_var(name, required=is_required, default=default).strip()
    if not is_secret:
        env_value = env_value.lower()

    return env_value


def run_methods_with_intervals(methods: list[Callable]):
    """Run the given methods in parallel with a specified interval."""
    
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = []
        for idx, method in enumerate(methods):
            # Schedule each method with a delay
            futures.append(executor.submit(delayed_execution, method))
            if idx != len(methods) - 1:
                utils.cloud_logging("Sleeping for {} seconds".format(METHOD_INTERVAL))
                time.sleep(METHOD_INTERVAL)

        # Wait for all methods to complete
        for future in concurrent.futures.as_completed(futures):
            try:    
                future.result()  # Raise exceptions if any occurred
            except Exception as e:
                utils.cloud_logging(f"Exception occurred while executing a method: {e}", severity="ERROR")


def delayed_execution(method: Callable):
    """Executes a method after a specified delay."""
    utils.cloud_logging("Executing {} method".format(method.__name__))
    method()
    utils.cloud_logging("Completed {} method".format(method.__name__))
